package com.qa.test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;

import com.qa.base.TestBase;
import com.qa.client.GetRestClient;

public class GetApiTest extends TestBase{
	
	public GetApiTest() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	TestBase testBase;
	String baseUrl;
	String apiResource;
	
	String uri;
	
	@Test
	public void setUp() throws IOException  {
		testBase = new TestBase();
		
		baseUrl = prop.getProperty("URL");
		apiResource =prop.getProperty("ServiceURL");
		
		uri = baseUrl+ apiResource;

		GetRestClient getRestClient = new GetRestClient();
		getRestClient.getWeather(uri);
	
		
	}

}

