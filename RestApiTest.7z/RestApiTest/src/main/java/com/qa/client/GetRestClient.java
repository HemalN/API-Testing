package com.qa.client;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class GetRestClient {

// Create Get Method
	
	public void getWeather(String uri) throws IOException, IOException {
		
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(uri);
		//httpClient.execute(httpGet);
		
		//Execute the URI and Get the Response
		CloseableHttpResponse httpResponse = httpClient.execute(httpGet); 
		
		int statusCode = httpResponse.getStatusLine().getStatusCode();
		int expStatusCode = 200;
		assertEquals(statusCode, expStatusCode);
		System.out.println(statusCode);
		
		String response = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
		
		JSONObject responseJson = new JSONObject(response);
		System.out.println(responseJson);
		
	}
	
}
